apt upgrade
apt install
apt install wget -y
apt install ffmpeg -y
apt install nodejs -y
npm i -g cwebp
npm i -g ytdl 
npm i
npm update
